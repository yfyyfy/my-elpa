;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker-tramp" "0.1.1"
  "TRAMP integration for docker containers."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/emacs-pe/docker-tramp.el"
  :commit "930d7b46c180d8a13240a028c1b40af84f2a3219"
  :revdesc "930d7b46c180"
  :keywords '("docker" "convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
