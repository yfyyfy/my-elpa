;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elpa-mirror" "2.3.0"
  "Create local package repository from installed packages."
  '((emacs "27.1"))
  :url "https://github.com/redguardtoo/elpa-mirror"
  :commit "d51a5b81af909727fac45f3c9d3653b1170e01f0"
  :revdesc "d51a5b81af90"
  :keywords '("tools")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
