;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "0.9.0"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "15a4be6bbe13220d9781e10d6e2086c21c3bc7ee"
  :revdesc "15a4be6bbe13"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
