;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "1.28.0"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "c56d0b2de8861773d86af4eef38be820604f42bb"
  :revdesc "c56d0b2de886"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
