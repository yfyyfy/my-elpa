;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avy-migemo" "20180716.1455"
  "Avy with migemo."
  '((emacs  "24.4")
    (avy    "0.4.0")
    (migemo "1.9"))
  :url "https://github.com/momomo5717/avy-migemo"
  :commit "922a6dd82c0bfa316b0fbb56a9d4dd4ffa5707e7"
  :revdesc "922a6dd82c0b"
  :keywords '("avy" "migemo"))
