;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.970"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "72c49e6f7c5817c81c2d425dcefeea2107d7c94a"
  :revdesc "72c49e6f7c58"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
